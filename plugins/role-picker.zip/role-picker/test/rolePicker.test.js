const test = require('node:test');
const assert = require('node:assert');
const { EventEmitter } = require('node:events');
const { PermissionsBitField, PermissionFlagsBits } = require('discord.js');

const { PREFIX, parseRoleButtons, unsafeReason } = require('../lib/roles');
const command = require('../commands/rolepicker');
const registerHandler = require('../handlers/rolePickerHandler');

const GUILD_ID = '100';

function fakeRole(overrides = {}) {
    return {
        id: '200',
        name: 'Français',
        guild: { id: GUILD_ID },
        managed: false,
        editable: true,
        permissions: new PermissionsBitField(overrides.perms || 0n),
        ...overrides
    };
}

function fakeGuild(roles) {
    return { id: GUILD_ID, roles: { cache: new Map(roles.map(r => [r.id, r])) } };
}

test('parseRoleButtons reads mentions with optional emoji and drops duplicates', () => {
    assert.deepStrictEqual(
        parseRoleButtons('<@&1> 🇫🇷 <@&2><@&3> <:flag:99>  <@&1> 🇩🇪'),
        [
            { roleId: '1', emoji: '🇫🇷' },
            { roleId: '2', emoji: null },
            { roleId: '3', emoji: '<:flag:99>' }
        ]
    );
    assert.deepStrictEqual(parseRoleButtons('no roles here'), []);
});

test('unsafeReason allows a plain role and rejects risky ones', () => {
    assert.strictEqual(unsafeReason(fakeRole()), null);
    assert.match(unsafeReason(fakeRole({ id: GUILD_ID })), /everyone/);
    assert.match(unsafeReason(fakeRole({ managed: true })), /integration/);
    assert.match(unsafeReason(fakeRole({ perms: PermissionFlagsBits.Administrator })), /moderation/);
    assert.match(unsafeReason(fakeRole({ perms: PermissionFlagsBits.KickMembers })), /moderation/);
    assert.match(unsafeReason(fakeRole({ editable: false })), /highest role/);
});

function commandInteraction({ rolesOption, roles, canManage = true }) {
    const sent = [];
    const replies = [];
    return {
        sent,
        replies,
        inGuild: () => true,
        memberPermissions: new PermissionsBitField(canManage ? PermissionFlagsBits.ManageRoles : 0n),
        options: { getString: name => (name === 'roles' ? rolesOption : null) },
        guild: fakeGuild(roles),
        channel: { send: async payload => { sent.push(payload); } },
        reply: async payload => { replies.push(payload); }
    };
}

test('/rolepicker posts one button per role', async () => {
    const roles = [fakeRole({ id: '1', name: 'Français' }), fakeRole({ id: '2', name: 'Deutsch' })];
    const interaction = commandInteraction({ rolesOption: '<@&1> 🇫🇷 <@&2>', roles });
    await command.execute(interaction);

    assert.strictEqual(interaction.sent.length, 1);
    const buttons = interaction.sent[0].components[0].toJSON().components;
    assert.deepStrictEqual(buttons.map(b => b.custom_id), [`${PREFIX}1`, `${PREFIX}2`]);
    assert.deepStrictEqual(buttons.map(b => b.label), ['Français', 'Deutsch']);
    assert.strictEqual(buttons[0].emoji.name, '🇫🇷');
    assert.strictEqual(buttons[1].emoji, undefined);
});

test('/rolepicker refuses privileged roles and members without Manage Roles', async () => {
    const admin = fakeRole({ id: '9', name: 'R4', perms: PermissionFlagsBits.Administrator });
    const withAdminRole = commandInteraction({ rolesOption: '<@&9>', roles: [admin] });
    await command.execute(withAdminRole);
    assert.strictEqual(withAdminRole.sent.length, 0);
    assert.match(withAdminRole.replies[0].content, /cannot be self-assigned/);

    const noPermission = commandInteraction({ rolesOption: '<@&1>', roles: [fakeRole({ id: '1' })], canManage: false });
    await command.execute(noPermission);
    assert.strictEqual(noPermission.sent.length, 0);
    assert.match(noPermission.replies[0].content, /Manage Roles/);
});

function click(client, { customId, role, memberRoleIds = [] }) {
    const added = [];
    const removed = [];
    const replies = [];
    const interaction = {
        isButton: () => true,
        customId,
        guild: fakeGuild(role ? [role] : []),
        member: {
            roles: {
                cache: new Set(memberRoleIds),
                add: async r => { added.push(r.id); },
                remove: async r => { removed.push(r.id); }
            }
        },
        reply: async payload => { replies.push(payload.content); }
    };
    client.emit('interactionCreate', interaction);
    return new Promise(resolve => setImmediate(() => resolve({ added, removed, replies })));
}

test('button click adds the role, a second click removes it', async () => {
    const client = new EventEmitter();
    const cleanup = registerHandler(client);
    const role = fakeRole({ id: '1', name: 'Français' });

    const first = await click(client, { customId: `${PREFIX}1`, role });
    assert.deepStrictEqual(first.added, ['1']);
    assert.deepStrictEqual(first.replies, ['✅ Français']);

    const second = await click(client, { customId: `${PREFIX}1`, role, memberRoleIds: ['1'] });
    assert.deepStrictEqual(second.removed, ['1']);
    assert.deepStrictEqual(second.replies, ['➖ Français']);

    cleanup();
    assert.strictEqual(client.listenerCount('interactionCreate'), 0);
});

test('button click ignores other plugins and refuses roles that became privileged', async () => {
    const client = new EventEmitter();
    registerHandler(client);

    const other = await click(client, { customId: 'multilingual-chat_x', role: fakeRole({ id: '1' }) });
    assert.deepStrictEqual(other.replies, []);

    const promoted = fakeRole({ id: '1', perms: PermissionFlagsBits.Administrator });
    const refused = await click(client, { customId: `${PREFIX}1`, role: promoted });
    assert.deepStrictEqual(refused.added, []);
    assert.match(refused.replies[0], /not available/);
});
