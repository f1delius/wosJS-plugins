const { MessageFlags } = require('discord.js');
const { PREFIX, unsafeReason } = require('../lib/roles');

/**
 * Toggles the role encoded in a role-picker button for the member who clicked it.
 */
module.exports = function (client) {
    async function listener(interaction) {
        if (!interaction.isButton()) return;
        if (!interaction.customId.startsWith(PREFIX)) return;

        const reply = content => interaction.reply({ content, flags: MessageFlags.Ephemeral }).catch(() => {});

        const role = interaction.guild?.roles.cache.get(interaction.customId.slice(PREFIX.length));
        // Re-checked on every click: the role may have gained permissions since the picker was posted.
        if (!role || unsafeReason(role)) return reply('⚠️ This role is not available.');

        const member = interaction.member;
        const hadRole = member.roles.cache.has(role.id);
        try {
            if (hadRole) await member.roles.remove(role);
            else await member.roles.add(role);
        } catch {
            return reply('⚠️ Could not change your role.');
        }

        return reply(`${hadRole ? '➖' : '✅'} ${role.name}`);
    }

    client.on('interactionCreate', listener);
    return () => client.off('interactionCreate', listener);
};
