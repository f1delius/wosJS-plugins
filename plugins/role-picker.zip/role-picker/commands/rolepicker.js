const { SlashCommandBuilder, MessageFlags, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { PREFIX, MAX_BUTTONS, parseRoleButtons, unsafeReason } = require('../lib/roles');

const ephemeral = { flags: MessageFlags.Ephemeral };

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rolepicker')
        .setDescription('Post a message with buttons that let members give themselves roles')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
        .addStringOption(o => o.setName('roles').setDescription('@Role emoji @Role2 emoji ... (emoji optional)').setRequired(true))
        .addStringOption(o => o.setName('message').setDescription('Text shown above the buttons')),

    async execute(interaction) {
        if (!interaction.inGuild()) {
            return interaction.reply({ content: 'Use this command in a server.', ...ephemeral });
        }
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.reply({ content: 'You need the **Manage Roles** permission to post a role picker.', ...ephemeral });
        }

        const entries = parseRoleButtons(interaction.options.getString('roles'));
        if (!entries.length || entries.length > MAX_BUTTONS) {
            return interaction.reply({ content: `Provide 1–${MAX_BUTTONS} role mentions, e.g. \`@Français 🇫🇷 @Deutsch 🇩🇪\`.`, ...ephemeral });
        }

        const buttons = [];
        for (const entry of entries) {
            const role = interaction.guild.roles.cache.get(entry.roleId);
            if (!role) {
                return interaction.reply({ content: `Unknown role: <@&${entry.roleId}>`, ...ephemeral });
            }
            const reason = unsafeReason(role);
            if (reason) {
                return interaction.reply({ content: `**${role.name}** cannot be self-assigned: ${reason}.`, ...ephemeral });
            }
            const button = new ButtonBuilder()
                .setCustomId(`${PREFIX}${role.id}`)
                .setLabel(role.name.slice(0, 80))
                .setStyle(ButtonStyle.Secondary);
            if (entry.emoji) button.setEmoji(entry.emoji);
            buttons.push(button);
        }

        const rows = [];
        for (let i = 0; i < buttons.length; i += 5) {
            rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
        }

        try {
            await interaction.channel.send({
                content: interaction.options.getString('message') || 'Pick your roles:',
                components: rows,
                allowedMentions: { parse: [] }
            });
        } catch (error) {
            return interaction.reply({ content: `Could not post the role picker: ${error.message}`, ...ephemeral });
        }

        return interaction.reply({ content: 'Role picker posted.', ...ephemeral });
    }
};
