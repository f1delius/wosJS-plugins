# Multilingual Chat

Automatically translates channel messages between languages using Google
Translate, delivered through per-channel webhooks so translations can appear as
the original author. Edits and deletes are mirrored, and Discord message
**forwards** are translated too.

## How it works

There are two ways to link channels:

1. **Auto-configured channels** — give a channel a language with
   `/translate set`. Every configured channel in the server then fans out to
   every other configured channel.
2. **Groups** — `/link create <name> #a en #b fr #c de` builds an explicit set
   of channels that mirror each other. Use groups when you only want *some*
   channels connected.

Messages posted in a source channel are translated into each target language and
sent via a webhook named `Multilingual Chat` (created automatically if the bot
has **Manage Webhooks**).

## Commands

### `/translate`

| Subcommand | Description |
|---|---|
| `set language:<code>` | Set this channel's language (accepts codes or names) |
| `disable` | Turn translations off for this channel |
| `status` | Show this channel's language, webhook health and sender mode |
| `list` | Full server overview |
| `sender mode:<user\|bot> [scope]` | Sender appearance; scope = `guild` (default), `channel`, `inherit` |
| `options …` | Behaviour toggles (see below) |
| `ignore add\|remove [channel] [category]` | Manage ignored channels / categories |
| `ignore prefixes value:<list\|clear>` | Command prefixes to skip |
| `ignore show` | Show ignore rules |
| `webhooks status` | Webhook health for this channel |
| `webhooks cleanup` | Remove duplicate / invalid webhooks (**owner only**) |

**`/translate options`** flags: `min_chars`, `skip_same_language`,
`reply_context`, `thread_support`, `fallback_indicator`, `translate_retries`,
`max_attachments`, `max_attachment_mb`, `mod_log_channel`, `clear_mod_log`.

### `/link`

| Subcommand | Description |
|---|---|
| `create group_name mappings` | Create or replace a group |
| `add group_name mappings` | Add channels to a group |
| `remove group_name channel` | Remove one channel from a group |
| `delete group_name` | Delete a group |
| `list` | List groups and configured channels |

`mappings` is a space-separated list of `#channel language` pairs, e.g.
`#general en #general-fr french #general-de de`.

## Permissions

- Configuration commands require **Manage Server** or bot-admin status.
- `/translate webhooks cleanup` requires the server owner or bot owner.
- The bot needs **Manage Webhooks** in every target channel.
- The **Message Content** intent must be enabled for the bot.

## Supported languages

`ar de en es fr hi id it ja ko nl pl pt ru sv tr uk vi zh-cn zh-tw`
(plus friendly names / regional variants like `english`, `brazilian portuguese`,
`en-US`).

## Development

```
nvm use           # Node 22 (matches the bot's better-sqlite3 build; see .nvmrc)
npm test          # runs the node:test suite in test/
```

Data lives in `multilingual-chat.db` (preserved across plugin updates). The DB
path can be overridden with `MULTILINGUAL_CHAT_DB_PATH` for tests.

See [IMPROVEMENTS.md](IMPROVEMENTS.md) for the roadmap / change status.
