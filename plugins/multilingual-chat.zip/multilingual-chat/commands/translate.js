const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const pluginDb = require('../pluginDb');
const { normalizeLanguage, isSupportedLanguage, SUPPORTED_LANGUAGE_CODES } = require('../lib/translationService');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('translate')
        .setDescription('Configure multilingual channel translation')
        .addSubcommand(subcommand =>
            subcommand
                .setName('set')
                .setDescription('Set the target language for this channel')
                .addStringOption(option =>
                    option
                        .setName('language')
                        .setDescription('Target language code, for example en, fr, es.')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('disable')
                .setDescription('Disable translations in this channel')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('status')
                .setDescription('Show the translation configuration for this channel')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('sender')
                .setDescription('Choose how translated webhook messages appear')
                .addStringOption(option =>
                    option
                        .setName('mode')
                        .setDescription('Send translations as the original user or as the bot')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Original user', value: 'user' },
                            { name: 'Bot', value: 'bot' }
                        )
                )
        ),

    async execute(interaction) {
        const channelId = interaction.channelId;
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'set') {
            const rawLanguage = interaction.options.getString('language');
            const language = normalizeLanguage(rawLanguage);

            if (!isSupportedLanguage(language)) {
                return await interaction.reply({
                    content: `Unsupported language code. Supported codes: ${SUPPORTED_LANGUAGE_CODES.join(', ')}`,
                    flags: MessageFlags.Ephemeral
                });
            }

            pluginDb.setChannelTargetLanguage(channelId, language, interaction.guildId);
            return await interaction.reply({
                content: `This channel is now set to **${language}**. Messages here will translate into other configured language channels.`,
                flags: MessageFlags.Ephemeral
            });
        }

        if (subcommand === 'disable') {
            pluginDb.setChannelTargetLanguage(channelId, '', interaction.guildId);
            return await interaction.reply({
                content: 'Channel translations have been disabled.',
                flags: MessageFlags.Ephemeral
            });
        }

        if (subcommand === 'status') {
            const config = pluginDb.getChannelConfig(channelId);
            if (!config || !config.target_language) {
                return await interaction.reply({
                    content: 'Translations are not enabled for this channel.',
                    flags: MessageFlags.Ephemeral
                });
            }

            const webhookStatus = config.webhook_id ? 'configured' : 'not yet created';
            const senderMode = config.send_as_user === 0 ? 'bot' : 'original user';
            return await interaction.reply({
                content: `This channel is set to **${config.target_language}**. Webhook is ${webhookStatus}. Sender mode is **${senderMode}**.`,
                flags: MessageFlags.Ephemeral
            });
        }

        if (subcommand === 'sender') {
            const mode = interaction.options.getString('mode');
            const sendAsUser = mode === 'user';
            pluginDb.setGuildSendAsUser(interaction.guildId, sendAsUser);

            return await interaction.reply({
                content: `Translations will now be sent as **${sendAsUser ? 'the original user' : 'the bot'}** for configured channels in this server.`,
                flags: MessageFlags.Ephemeral
            });
        }
    }
};
