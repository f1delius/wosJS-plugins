const { SlashCommandBuilder, MessageFlags, ChannelType } = require('discord.js');
const pluginDb = require('../pluginDb');
const settings = require('../lib/settings');
const { isManager, isOwner, channelLabel } = require('../lib/commandHelpers');
const { resolveLanguage, isSupportedLanguage, languageLabel, SUPPORTED_LANGUAGE_CODES } = require('../lib/languages');
const { webhookHealth, cleanupWebhooks } = require('../lib/translationService');

const ephemeral = { flags: MessageFlags.Ephemeral };

module.exports = {
    data: new SlashCommandBuilder()
        .setName('translate')
        .setDescription('Configure multilingual channel translation')
        .addSubcommand(sub =>
            sub.setName('set')
                .setDescription('Set the target language for this channel')
                .addStringOption(o => o.setName('language').setDescription('Language code or name, e.g. en / french').setRequired(true))
        )
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable translations in this channel'))
        .addSubcommand(sub => sub.setName('status').setDescription('Show this channel\'s translation configuration'))
        .addSubcommand(sub => sub.setName('list').setDescription('List every configured channel and group for this server'))
        .addSubcommand(sub =>
            sub.setName('sender')
                .setDescription('Choose how translated webhook messages appear')
                .addStringOption(o => o.setName('mode').setDescription('Show as the original user or as the bot').setRequired(true)
                    .addChoices({ name: 'Original user', value: 'user' }, { name: 'Bot', value: 'bot' }))
                .addStringOption(o => o.setName('scope').setDescription('Where to apply this (default: whole server)')
                    .addChoices(
                        { name: 'Whole server', value: 'guild' },
                        { name: 'This channel only', value: 'channel' },
                        { name: 'Inherit server default (this channel)', value: 'inherit' }
                    ))
        )
        .addSubcommand(sub =>
            sub.setName('options')
                .setDescription('Tune translation behaviour for this server')
                .addIntegerOption(o => o.setName('min_chars').setDescription('Skip messages shorter than this (0 = off)').setMinValue(0).setMaxValue(500))
                .addBooleanOption(o => o.setName('skip_same_language').setDescription('Skip a target when the message is already in that language'))
                .addBooleanOption(o => o.setName('reply_context').setDescription('Show "reply to X" context on translated replies'))
                .addBooleanOption(o => o.setName('thread_support').setDescription('Mirror thread messages into same-named target threads'))
                .addBooleanOption(o => o.setName('fallback_indicator').setDescription('Mark messages sent untranslated after a failure'))
                .addIntegerOption(o => o.setName('translate_retries').setDescription('Retry attempts for transient failures').setMinValue(0).setMaxValue(5))
                .addIntegerOption(o => o.setName('max_attachments').setDescription('Max forwarded attachments per message (1-10)').setMinValue(1).setMaxValue(10))
                .addIntegerOption(o => o.setName('max_attachment_mb').setDescription('Per-file size cap in MB; larger files posted as links').setMinValue(1).setMaxValue(100))
                .addChannelOption(o => o.setName('mod_log_channel').setDescription('Channel for failure / permission logs').addChannelTypes(ChannelType.GuildText))
                .addBooleanOption(o => o.setName('clear_mod_log').setDescription('Stop moderation logging'))
        )
        .addSubcommandGroup(group =>
            group.setName('ignore')
                .setDescription('Manage what the plugin skips')
                .addSubcommand(sub =>
                    sub.setName('add').setDescription('Ignore a channel or a whole category')
                        .addChannelOption(o => o.setName('channel').setDescription('Channel to ignore'))
                        .addChannelOption(o => o.setName('category').setDescription('Category to ignore').addChannelTypes(ChannelType.GuildCategory)))
                .addSubcommand(sub =>
                    sub.setName('remove').setDescription('Stop ignoring a channel or category')
                        .addChannelOption(o => o.setName('channel').setDescription('Channel to stop ignoring'))
                        .addChannelOption(o => o.setName('category').setDescription('Category to stop ignoring').addChannelTypes(ChannelType.GuildCategory)))
                .addSubcommand(sub =>
                    sub.setName('prefixes').setDescription('Set message prefixes that are treated as commands and skipped')
                        .addStringOption(o => o.setName('value').setDescription('Comma-separated prefixes, or "clear"').setRequired(true)))
                .addSubcommand(sub => sub.setName('show').setDescription('Show current ignore rules'))
        )
        .addSubcommandGroup(group =>
            group.setName('webhooks')
                .setDescription('Inspect and clean up plugin webhooks')
                .addSubcommand(sub => sub.setName('status').setDescription('Show webhook health for this channel'))
                .addSubcommand(sub => sub.setName('cleanup').setDescription('Remove duplicate/invalid plugin webhooks (owner only)'))
        ),

    async execute(interaction) {
        if (!interaction.inGuild()) {
            return interaction.reply({ content: 'Use this command in a server.', ...ephemeral });
        }
        if (!isManager(interaction)) {
            return interaction.reply({ content: 'You need the **Manage Server** permission (or bot admin) to configure translations.', ...ephemeral });
        }

        const group = interaction.options.getSubcommandGroup(false);
        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guildId;
        const channelId = interaction.channelId;

        if (group === 'ignore') return handleIgnore(interaction, guildId, sub);
        if (group === 'webhooks') return handleWebhooks(interaction, guildId, sub);

        if (sub === 'set') {
            const language = resolveLanguage(interaction.options.getString('language'));
            if (!isSupportedLanguage(language)) {
                return interaction.reply({ content: `Unsupported language. Supported: ${SUPPORTED_LANGUAGE_CODES.join(', ')}`, ...ephemeral });
            }
            pluginDb.setChannelTargetLanguage(channelId, language, guildId);
            return interaction.reply({ content: `This channel is now **${languageLabel(language)}**. Messages here translate into other configured channels.`, ...ephemeral });
        }

        if (sub === 'disable') {
            pluginDb.setChannelTargetLanguage(channelId, '', guildId);
            return interaction.reply({ content: 'Channel translations disabled.', ...ephemeral });
        }

        if (sub === 'status') {
            const config = pluginDb.getChannelConfig(channelId);
            if (!config || !config.target_language) {
                return interaction.reply({ content: 'Translations are not enabled for this channel.', ...ephemeral });
            }
            const health = await webhookHealth(interaction.channel).catch(() => ({ stored: false, valid: false, canManage: false }));
            const webhookState = health.valid ? 'healthy' : health.stored ? 'stored but invalid' : health.canManage ? 'not created yet' : 'blocked (missing Manage Webhooks)';
            const senderMode = pluginDb.resolveSendMode(channelId, guildId);
            return interaction.reply({
                content: [
                    `Language: **${languageLabel(config.target_language)}**`,
                    `Webhook: **${webhookState}**`,
                    `Sender: **${senderMode === 'user' ? 'original user' : 'bot'}**${config.send_mode ? ' (channel override)' : ''}`
                ].join('\n'),
                ...ephemeral
            });
        }

        if (sub === 'list') return handleList(interaction, guildId);
        if (sub === 'sender') return handleSender(interaction, guildId, channelId);
        if (sub === 'options') return handleOptions(interaction, guildId);
    }
};

function handleSender(interaction, guildId, channelId) {
    const mode = interaction.options.getString('mode');
    const scope = interaction.options.getString('scope') || 'guild';

    if (scope === 'channel') {
        pluginDb.setChannelSendMode(channelId, mode);
        return interaction.reply({ content: `This channel will send translations as **${mode === 'user' ? 'the original user' : 'the bot'}**.`, ...ephemeral });
    }
    if (scope === 'inherit') {
        pluginDb.setChannelSendMode(channelId, null);
        return interaction.reply({ content: 'This channel now inherits the server default sender mode.', ...ephemeral });
    }
    pluginDb.setGuildSendMode(guildId, mode);
    return interaction.reply({ content: `Server default: translations sent as **${mode === 'user' ? 'the original user' : 'the bot'}** (per-channel overrides cleared).`, ...ephemeral });
}

function handleOptions(interaction, guildId) {
    const changes = [];
    const applyBool = (key, label) => {
        const value = interaction.options.getBoolean(key);
        if (value !== null) { settings.setBool(guildId, key, value); changes.push(`${label}: **${value ? 'on' : 'off'}**`); }
    };
    const applyInt = (key, label) => {
        const value = interaction.options.getInteger(key);
        if (value !== null) { settings.set(guildId, key, value); changes.push(`${label}: **${value}**`); }
    };

    applyInt('min_chars', 'Minimum characters');
    applyBool('skip_same_language', 'Skip same language');
    applyBool('reply_context', 'Reply context');
    applyBool('thread_support', 'Thread support');
    applyBool('fallback_indicator', 'Fallback indicator');
    applyInt('translate_retries', 'Translation retries');
    applyInt('max_attachments', 'Max attachments');
    applyInt('max_attachment_mb', 'Max attachment MB');

    const modLog = interaction.options.getChannel('mod_log_channel');
    if (modLog) { settings.set(guildId, 'mod_log_channel', modLog.id); changes.push(`Mod log: ${channelLabel(interaction.guild, modLog.id)}`); }
    if (interaction.options.getBoolean('clear_mod_log')) { settings.set(guildId, 'mod_log_channel', ''); changes.push('Mod log: **disabled**'); }

    if (!changes.length) {
        const d = settings.describe(guildId);
        return interaction.reply({
            content: [
                '**Current options**',
                `Minimum characters: **${d.min_chars}**`,
                `Skip same language: **${d.skip_same_language ? 'on' : 'off'}**`,
                `Reply context: **${d.reply_context ? 'on' : 'off'}**`,
                `Thread support: **${d.thread_support ? 'on' : 'off'}**`,
                `Fallback indicator: **${d.fallback_indicator ? 'on' : 'off'}**`,
                `Translation retries: **${d.translate_retries}**`,
                `Max attachments: **${d.max_attachments}**`,
                `Max attachment MB: **${d.max_attachment_mb}**`,
                `Mod log channel: ${d.mod_log_channel ? channelLabel(interaction.guild, d.mod_log_channel) : '**none**'}`
            ].join('\n'),
            ...ephemeral
        });
    }

    return interaction.reply({ content: `Updated:\n${changes.join('\n')}`, ...ephemeral });
}

function handleIgnore(interaction, guildId, sub) {
    if (sub === 'prefixes') {
        const value = interaction.options.getString('value').trim();
        if (value.toLowerCase() === 'clear') {
            settings.set(guildId, 'ignore_prefixes', '');
            return interaction.reply({ content: 'Command-prefix filtering disabled.', ...ephemeral });
        }
        const prefixes = value.split(',').map(s => s.trim()).filter(Boolean);
        settings.set(guildId, 'ignore_prefixes', prefixes.join(','));
        return interaction.reply({ content: `Messages starting with ${prefixes.map(p => `\`${p}\``).join(' ')} will be skipped.`, ...ephemeral });
    }

    if (sub === 'show') {
        const d = settings.describe(guildId);
        return interaction.reply({
            content: [
                `Ignored prefixes: ${d.ignore_prefixes.length ? d.ignore_prefixes.map(p => `\`${p}\``).join(' ') : '**none**'}`,
                `Ignored channels: ${d.ignore_channels.length ? d.ignore_channels.map(id => channelLabel(interaction.guild, id)).join(', ') : '**none**'}`,
                `Ignored categories: ${d.ignore_categories.length ? d.ignore_categories.map(id => channelLabel(interaction.guild, id)).join(', ') : '**none**'}`
            ].join('\n'),
            ...ephemeral
        });
    }

    const channel = interaction.options.getChannel('channel');
    const category = interaction.options.getChannel('category');
    if (!channel && !category) {
        return interaction.reply({ content: 'Specify a `channel` or a `category`.', ...ephemeral });
    }

    const op = sub === 'add' ? settings.addToList : settings.removeFromList;
    const done = [];
    if (channel) { op(guildId, 'ignore_channels', channel.id); done.push(channelLabel(interaction.guild, channel.id)); }
    if (category) { op(guildId, 'ignore_categories', category.id); done.push(channelLabel(interaction.guild, category.id)); }

    return interaction.reply({
        content: `${sub === 'add' ? 'Now ignoring' : 'No longer ignoring'}: ${done.join(', ')}`,
        ...ephemeral
    });
}

async function handleWebhooks(interaction, guildId, sub) {
    if (sub === 'status') {
        const health = await webhookHealth(interaction.channel).catch(() => null);
        if (!health) return interaction.reply({ content: 'Could not check webhook health here.', ...ephemeral });
        return interaction.reply({
            content: [
                `Stored webhook: **${health.stored ? 'yes' : 'no'}**`,
                `Valid: **${health.valid ? 'yes' : 'no'}**`,
                `Bot can manage webhooks: **${health.canManage ? 'yes' : 'no'}**`
            ].join('\n'),
            ...ephemeral
        });
    }

    if (sub === 'cleanup') {
        if (!isOwner(interaction)) {
            return interaction.reply({ content: 'Only the bot owner or server owner can run webhook cleanup.', ...ephemeral });
        }
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const result = await cleanupWebhooks(interaction.guild);
        return interaction.editReply({
            content: `Cleanup complete. Kept ${result.kept} webhook(s) across ${result.channels} channel(s), removed ${result.removed} duplicate(s).`
        });
    }
}

function handleList(interaction, guildId) {
    const groups = pluginDb.getGuildGroupNames(guildId);
    const configured = pluginDb.getGuildChannelConfigs(guildId);
    const lines = [];

    if (groups.length) {
        lines.push('**Groups**');
        for (const groupName of groups) {
            lines.push(`• **${groupName}**: ` + pluginDb.getGroupChannels(groupName, guildId)
                .map(c => `${channelLabel(interaction.guild, c.channel_id)}→${resolveLanguage(c.target_language)}`).join(', '));
        }
    }
    if (configured.length) {
        lines.push('');
        lines.push('**Configured channels**');
        for (const c of configured) {
            lines.push(`${c.webhook_id ? '🟢' : '⚪'} ${channelLabel(interaction.guild, c.channel_id)} → ${languageLabel(c.target_language)}`);
        }
    }
    const d = settings.describe(guildId);
    lines.push('');
    lines.push(`_Sender default: **${d.send_mode}** · min chars: ${d.min_chars} · skip-same-language: ${d.skip_same_language ? 'on' : 'off'}_`);

    return interaction.reply({ content: lines.join('\n').slice(0, 1900) || 'Nothing configured yet.', ...ephemeral });
}
