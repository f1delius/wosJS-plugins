const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const pluginDb = require('../pluginDb');
const { isManager, parseMappings, channelLabel } = require('../lib/commandHelpers');
const { languageLabel } = require('../lib/languages');

const ephemeral = { flags: MessageFlags.Ephemeral };

module.exports = {
    data: new SlashCommandBuilder()
        .setName('link')
        .setDescription('Manage translation groups (linked channels that mirror each other)')
        .addSubcommand(sub =>
            sub.setName('create')
                .setDescription('Create or replace a translation group')
                .addStringOption(o => o.setName('group_name').setDescription('Group name').setRequired(true))
                .addStringOption(o => o.setName('mappings').setDescription('#channel lang #channel2 lang2 ...').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('add')
                .setDescription('Add channels to an existing group without retyping it')
                .addStringOption(o => o.setName('group_name').setDescription('Group name').setRequired(true))
                .addStringOption(o => o.setName('mappings').setDescription('#channel lang #channel2 lang2 ...').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('remove')
                .setDescription('Remove one channel from a group')
                .addStringOption(o => o.setName('group_name').setDescription('Group name').setRequired(true))
                .addChannelOption(o => o.setName('channel').setDescription('Channel to remove').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('delete')
                .setDescription('Delete an entire translation group')
                .addStringOption(o => o.setName('group_name').setDescription('Group name').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('list')
                .setDescription('List translation groups and configured channels for this server')
        ),

    async execute(interaction) {
        if (!interaction.inGuild()) {
            return interaction.reply({ content: 'Use this command in a server.', ...ephemeral });
        }
        if (!isManager(interaction)) {
            return interaction.reply({ content: 'You need the **Manage Server** permission (or bot admin) to configure translations.', ...ephemeral });
        }

        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guildId;

        if (sub === 'list') {
            return handleList(interaction, guildId);
        }

        if (sub === 'delete') {
            const groupName = interaction.options.getString('group_name').trim();
            const removed = pluginDb.deleteGroup(groupName, guildId);
            return interaction.reply({
                content: removed ? `Deleted group **${groupName}**.` : `No group named **${groupName}** in this server.`,
                ...ephemeral
            });
        }

        if (sub === 'remove') {
            const groupName = interaction.options.getString('group_name').trim();
            const channel = interaction.options.getChannel('channel');
            const removed = pluginDb.removeGroupChannel(groupName, guildId, channel.id);
            return interaction.reply({
                content: removed
                    ? `Removed ${channelLabel(interaction.guild, channel.id)} from **${groupName}**.`
                    : `${channelLabel(interaction.guild, channel.id)} is not part of **${groupName}**.`,
                ...ephemeral
            });
        }

        // create / add
        const groupName = interaction.options.getString('group_name').trim();
        const parsed = await parseMappings(interaction.guild, interaction.options.getString('mappings'));
        if (!parsed.ok) {
            return interaction.reply({ content: parsed.error, ...ephemeral });
        }

        for (const entry of parsed.entries) {
            pluginDb.setChannelTargetLanguage(entry.channelId, entry.targetLanguage, guildId);
        }

        if (sub === 'create') {
            pluginDb.setGroupChannels(groupName, guildId, parsed.entries);
        } else {
            pluginDb.addGroupChannels(groupName, guildId, parsed.entries);
        }

        const summary = parsed.entries
            .map(e => `${channelLabel(interaction.guild, e.channelId)} → ${languageLabel(e.targetLanguage)}`)
            .join('\n');

        return interaction.reply({
            content: `${sub === 'create' ? 'Created' : 'Updated'} group **${groupName}**:\n${summary}`,
            ...ephemeral
        });
    }
};

async function handleList(interaction, guildId) {
    const groups = pluginDb.getGuildGroupNames(guildId);
    const configured = pluginDb.getGuildChannelConfigs(guildId);

    const lines = [];

    if (groups.length) {
        lines.push('**Translation groups**');
        for (const groupName of groups) {
            const channels = pluginDb.getGroupChannels(groupName, guildId);
            lines.push(`• **${groupName}**`);
            for (const ch of channels) {
                const mode = ch.send_mode ? ` _(as ${ch.send_mode})_` : '';
                lines.push(`   ${channelLabel(interaction.guild, ch.channel_id)} → ${languageLabel(ch.target_language)}${mode}`);
            }
        }
    }

    const groupChannelIds = new Set(
        groups.flatMap(g => pluginDb.getGroupChannels(g, guildId).map(c => c.channel_id))
    );
    const soloChannels = configured.filter(c => !groupChannelIds.has(c.channel_id));

    if (soloChannels.length) {
        lines.push('');
        lines.push('**Auto-configured channels** (fan out to every other configured channel)');
        for (const ch of soloChannels) {
            const webhook = ch.webhook_id ? '🟢' : '⚪';
            const mode = ch.send_mode ? ` _(as ${ch.send_mode})_` : '';
            lines.push(`${webhook} ${channelLabel(interaction.guild, ch.channel_id)} → ${languageLabel(ch.target_language)}${mode}`);
        }
    }

    if (!lines.length) {
        return interaction.reply({ content: 'No translation groups or channels configured yet. Use `/link create` or `/translate set`.', ...ephemeral });
    }

    return interaction.reply({ content: lines.join('\n').slice(0, 1900), ...ephemeral });
}
