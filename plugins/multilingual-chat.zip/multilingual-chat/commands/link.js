const { SlashCommandBuilder, ChannelType, MessageFlags } = require('discord.js');
const pluginDb = require('../pluginDb');
const { normalizeLanguage, isSupportedLanguage, SUPPORTED_LANGUAGE_CODES } = require('../lib/translationService');

function parseChannelMention(value) {
    const match = /^<#(\d+)>$/.exec(value.trim());
    return match ? match[1] : value.trim();
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('link')
        .setDescription('Link channels into a translation group')
        .addStringOption(option =>
            option
                .setName('group_name')
                .setDescription('Name of the translation group')
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName('mappings')
                .setDescription('Space-separated channel and language pairs: #channel en #other fr')
                .setRequired(true)
        ),

    async execute(interaction) {
        const groupName = interaction.options.getString('group_name').trim();
        const mappings = interaction.options.getString('mappings').trim();
        const tokens = mappings.split(/\s+/);

        if (tokens.length < 2 || tokens.length % 2 !== 0) {
            return await interaction.reply({
                content: 'Mappings must be provided as pairs of channel and language, for example: #chats en #epl-here fr',
                flags: MessageFlags.Ephemeral
            });
        }

        const channelEntries = [];
        for (let i = 0; i < tokens.length; i += 2) {
            const rawChannel = tokens[i];
            const rawLanguage = tokens[i + 1];
            const channelId = parseChannelMention(rawChannel);
            const language = normalizeLanguage(rawLanguage);

            if (!isSupportedLanguage(language)) {
                return await interaction.reply({
                    content: `Unsupported language code: ${rawLanguage}. Supported: ${SUPPORTED_LANGUAGE_CODES.join(', ')}`,
                    flags: MessageFlags.Ephemeral
                });
            }

            const channel = interaction.guild.channels.cache.get(channelId) || await interaction.guild.channels.fetch(channelId).catch(() => null);
            if (!channel || channel.type !== ChannelType.GuildText) {
                return await interaction.reply({
                    content: `Invalid text channel: ${rawChannel}`,
                    flags: MessageFlags.Ephemeral
                });
            }

            channelEntries.push({ channelId, targetLanguage: language });
        }

        for (const entry of channelEntries) {
            pluginDb.setChannelTargetLanguage(entry.channelId, entry.targetLanguage, interaction.guildId);
        }

        pluginDb.setGroupChannels(groupName, interaction.guildId, channelEntries);

        return await interaction.reply({
            content: `Linked ${channelEntries.length} channel(s) in group **${groupName}**. Messages from any listed channel are translated into the others.`,
            flags: MessageFlags.Ephemeral
        });
    }
};
