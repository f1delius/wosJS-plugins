# Multilingual Chat Improvements

Status of the planned improvements. ✅ = implemented in v1.1.0, ⬜ = still open.

## Command Management

- ✅ `/link add` — add channels to an existing group without retyping it.
- ✅ `/link remove` — remove a channel from a group.
- ✅ `/link list` and `/translate list` — show configured channels, languages, group
  names, webhook status and sender mode for the server.
- ✅ `/link delete` — remove an entire group.
- ✅ `/link create` — replaces the old default `/link` behaviour.
- ✅ Language aliases — `english`, `french`, `simplified chinese`, `en-US`, … all
  resolve to supported codes (`lib/languages.js`).

## Translation Behavior

- ✅ Ignore rules: bot/webhook/system messages, command-like prefixes
  (`/translate ignore prefixes`), selected channels and categories
  (`/translate ignore add|remove`), and a minimum character count
  (`/translate options min_chars`).
- ✅ Fallback indicator when translation fails and the original text is sent
  (`/translate options fallback_indicator`).
- ✅ Reply context — translated replies are prefixed with "reply to X: …"
  (`/translate options reply_context`).
- ✅ Thread support — thread messages mirror into a same-named thread in the
  target channel when one exists (`/translate options thread_support`).
- ✅ Skip translation when the source text is already in the target language
  (`/translate options skip_same_language`).
- ✅ Forwarded messages — Discord message forwards are unwrapped from
  `messageSnapshots` and translated/mirrored like normal messages.

## Attachments And Media

- ✅ Image/GIF/video/file attachments are preserved when text is translated.
- ✅ Attachment-only messages are handled (no text required).
- ✅ Attachments Discord cannot re-send fall back to being posted as links.
- ✅ Configurable count and size limits (`/translate options max_attachments`,
  `max_attachment_mb`); over-limit files are linked instead of uploaded.

## Webhooks

- ✅ One stored webhook per channel, reused and cached in-process.
- ✅ Existing `Multilingual Chat` webhook is reused before creating a new one.
- ✅ Owner-only cleanup command for duplicate / invalid webhooks
  (`/translate webhooks cleanup`).
- ✅ Webhook health in `/translate status` and `/translate webhooks status`.

## Sender Mode

- ✅ `/translate sender user` / `bot` for the server default.
- ✅ Per-channel override (`/translate sender mode:… scope:channel`) and
  `scope:inherit` to clear it. Per-group-channel overrides are stored too.

## Moderation And Safety

- ✅ `allowedMentions: { parse: [] }` on every outgoing message.
- ✅ Optional moderation logging for failed translations, missing webhook
  permissions and skipped attachments (`/translate options mod_log_channel`).
- ✅ Permission checks with clear errors when the bot cannot manage webhooks.
- ✅ Config commands require Manage Server / bot admin; cleanup requires owner.

## Reliability

- ✅ Retries with backoff for transient translation failures
  (`/translate options translate_retries`).
- ✅ Per-guild translation queue with a cooldown gap (`lib/queue.js`) so busy
  channels cannot fan out dozens of concurrent requests.
- ✅ Tests for language resolution, DB CRUD + sender resolution, forward
  unwrapping, attachment limits, ignore rules and body building (`test/`,
  run with `npm test`).
- ✅ Migration test that loads a v1.0.0-shaped database and asserts the new
  columns / tables are added without data loss.

## Still open

- ⬜ Translating forwarded **embeds** (link previews / rich embeds) — currently
  only text + attachments carry over.
- ⬜ Auto-creating a matching thread in the target channel when one does not
  already exist (today it only mirrors into existing threads).
- ⬜ Full i18n of command responses (locale files exist; responses are still
  English).
