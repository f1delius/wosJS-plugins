/**
 * Multilingual Chat Plugin Database
 *
 * Stores channel configuration, translation groups, per-guild settings and
 * translated message mappings using SQLite. The database file lives beside this
 * module and is preserved across plugin updates (see plugin.json).
 *
 * The path can be overridden with MULTILINGUAL_CHAT_DB_PATH (used by tests).
 */

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = process.env.MULTILINGUAL_CHAT_DB_PATH || path.join(__dirname, 'multilingual-chat.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS channel_config (
    channel_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL DEFAULT '',
    target_language TEXT NOT NULL DEFAULT '',
    webhook_id TEXT,
    webhook_token TEXT,
    send_as_user INTEGER NOT NULL DEFAULT 1,
    send_mode TEXT
);

CREATE TABLE IF NOT EXISTS group_channels (
    group_name TEXT NOT NULL,
    guild_id TEXT NOT NULL DEFAULT '',
    channel_id TEXT NOT NULL,
    target_language TEXT NOT NULL,
    send_mode TEXT,
    PRIMARY KEY (group_name, channel_id)
);

CREATE TABLE IF NOT EXISTS message_map (
    original_message_id TEXT NOT NULL,
    target_channel_id TEXT NOT NULL,
    webhook_message_id TEXT NOT NULL,
    target_language TEXT NOT NULL,
    thread_id TEXT,
    PRIMARY KEY (original_message_id, target_channel_id)
);

CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    PRIMARY KEY (guild_id, key)
);
`);

// ------------------------------------------------------------------
// Lightweight migrations for databases created by older plugin versions
// ------------------------------------------------------------------
function columnNames(table) {
    return db.prepare(`PRAGMA table_info(${table})`).all().map(row => row.name);
}

function ensureColumn(table, column, definition) {
    if (!columnNames(table).includes(column)) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
        return true;
    }
    return false;
}

ensureColumn('channel_config', 'guild_id', "TEXT NOT NULL DEFAULT ''");
ensureColumn('channel_config', 'send_as_user', 'INTEGER NOT NULL DEFAULT 1');
const addedChannelSendMode = ensureColumn('channel_config', 'send_mode', 'TEXT');
ensureColumn('group_channels', 'guild_id', "TEXT NOT NULL DEFAULT ''");
ensureColumn('group_channels', 'send_mode', 'TEXT');
ensureColumn('message_map', 'thread_id', 'TEXT');

// Carry the legacy per-channel send_as_user flag into the newer send_mode column.
if (addedChannelSendMode) {
    db.exec("UPDATE channel_config SET send_mode = 'bot' WHERE send_as_user = 0 AND send_mode IS NULL");
}

// ------------------------------------------------------------------
// Prepared statements
// ------------------------------------------------------------------
const getChannelConfigStmt = db.prepare('SELECT channel_id, guild_id, target_language, webhook_id, webhook_token, send_as_user, send_mode FROM channel_config WHERE channel_id = ?');
const getGuildChannelConfigsStmt = db.prepare("SELECT channel_id, target_language, webhook_id, send_mode FROM channel_config WHERE guild_id = ? AND target_language != '' ORDER BY channel_id");
const setChannelConfigStmt = db.prepare(`INSERT INTO channel_config (channel_id, guild_id, target_language, webhook_id, webhook_token, send_as_user, send_mode)
    VALUES (@channel_id, @guild_id, @target_language, @webhook_id, @webhook_token, @send_as_user, @send_mode)
    ON CONFLICT(channel_id) DO UPDATE SET guild_id = excluded.guild_id, target_language = excluded.target_language
`);
const setChannelWebhookStmt = db.prepare(`INSERT INTO channel_config (channel_id, guild_id, target_language, webhook_id, webhook_token, send_as_user, send_mode)
    VALUES (@channel_id, @guild_id, @target_language, @webhook_id, @webhook_token, @send_as_user, @send_mode)
    ON CONFLICT(channel_id) DO UPDATE SET webhook_id = excluded.webhook_id, webhook_token = excluded.webhook_token
`);
const setChannelSendModeStmt = db.prepare('UPDATE channel_config SET send_mode = ? WHERE channel_id = ?');
const clearGuildChannelSendModeStmt = db.prepare('UPDATE channel_config SET send_mode = NULL WHERE guild_id = ?');
const deleteChannelConfigStmt = db.prepare('DELETE FROM channel_config WHERE channel_id = ?');
const getConfiguredTargetsStmt = db.prepare(`
    SELECT target.channel_id AS target_channel_id, target.target_language
    FROM channel_config AS source
    JOIN channel_config AS target ON target.guild_id = source.guild_id
    WHERE source.channel_id = ?
      AND source.guild_id = ?
      AND source.target_language != ''
      AND target.target_language != ''
      AND target.channel_id != source.channel_id
`);

const getGroupTargetsStmt = db.prepare(`
    SELECT DISTINCT gc.channel_id AS target_channel_id, gc.target_language
    FROM group_channels AS gc
    JOIN group_channels AS src ON src.group_name = gc.group_name
        AND src.guild_id = gc.guild_id
    WHERE src.group_name = ?
      AND src.guild_id = ?
      AND src.channel_id = ?
      AND gc.channel_id != src.channel_id
`);
const getGroupsForSourceStmt = db.prepare('SELECT DISTINCT group_name FROM group_channels WHERE guild_id = ? AND channel_id = ?');
const getGroupChannelsStmt = db.prepare('SELECT channel_id, target_language, send_mode FROM group_channels WHERE group_name = ? AND guild_id = ? ORDER BY channel_id');
const getGroupChannelStmt = db.prepare('SELECT channel_id, target_language, send_mode FROM group_channels WHERE group_name = ? AND channel_id = ?');
const getGuildGroupNamesStmt = db.prepare('SELECT DISTINCT group_name FROM group_channels WHERE guild_id = ? ORDER BY group_name');
const getAllGroupNamesStmt = db.prepare('SELECT DISTINCT group_name FROM group_channels');
const deleteGroupStmt = db.prepare('DELETE FROM group_channels WHERE group_name = ? AND guild_id = ?');
const deleteGroupChannelStmt = db.prepare('DELETE FROM group_channels WHERE group_name = ? AND guild_id = ? AND channel_id = ?');
const insertGroupChannelStmt = db.prepare(`INSERT INTO group_channels (group_name, guild_id, channel_id, target_language, send_mode)
    VALUES (?, ?, ?, ?, NULL)
    ON CONFLICT(group_name, channel_id) DO UPDATE SET guild_id = excluded.guild_id, target_language = excluded.target_language`);
const setGroupChannelSendModeStmt = db.prepare('UPDATE group_channels SET send_mode = ? WHERE group_name = ? AND guild_id = ? AND channel_id = ?');

const getMessageMappingStmt = db.prepare('SELECT target_channel_id, webhook_message_id, target_language, thread_id FROM message_map WHERE original_message_id = ? AND target_channel_id = ?');
const getMessageMappingsStmt = db.prepare('SELECT target_channel_id, webhook_message_id, target_language, thread_id FROM message_map WHERE original_message_id = ?');
const insertMessageMappingStmt = db.prepare(`INSERT OR REPLACE INTO message_map (original_message_id, target_channel_id, webhook_message_id, target_language, thread_id)
    VALUES (?, ?, ?, ?, ?)
`);
const deleteMessageMappingsStmt = db.prepare('DELETE FROM message_map WHERE original_message_id = ?');

const getGuildSettingStmt = db.prepare('SELECT value FROM guild_settings WHERE guild_id = ? AND key = ?');
const getGuildSettingsStmt = db.prepare('SELECT key, value FROM guild_settings WHERE guild_id = ?');
const setGuildSettingStmt = db.prepare('INSERT INTO guild_settings (guild_id, key, value) VALUES (?, ?, ?) ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value');
const deleteGuildSettingStmt = db.prepare('DELETE FROM guild_settings WHERE guild_id = ? AND key = ?');

// ------------------------------------------------------------------
// Channel configuration
// ------------------------------------------------------------------
function getChannelConfig(channelId) {
    return getChannelConfigStmt.get(channelId);
}

function getGuildChannelConfigs(guildId) {
    return getGuildChannelConfigsStmt.all(guildId || '');
}

function getChannelTargetLanguage(channelId) {
    const config = getChannelConfig(channelId);
    return config ? config.target_language : '';
}

function setChannelTargetLanguage(channelId, targetLanguage, guildId = '') {
    const stored = getChannelConfig(channelId);
    setChannelConfigStmt.run({
        channel_id: channelId,
        guild_id: guildId || stored?.guild_id || '',
        target_language: targetLanguage || '',
        webhook_id: stored ? stored.webhook_id : null,
        webhook_token: stored ? stored.webhook_token : null,
        send_as_user: stored ? stored.send_as_user : 1,
        send_mode: stored ? stored.send_mode : null
    });
}

function setChannelWebhook(channelId, webhookId, webhookToken) {
    const stored = getChannelConfig(channelId);
    setChannelWebhookStmt.run({
        channel_id: channelId,
        guild_id: stored?.guild_id || '',
        target_language: stored ? stored.target_language : '',
        webhook_id: webhookId,
        webhook_token: webhookToken,
        send_as_user: stored ? stored.send_as_user : 1,
        send_mode: stored ? stored.send_mode : null
    });
}

function clearChannelWebhook(channelId) {
    setChannelWebhook(channelId, null, null);
}

function deleteChannelConfig(channelId) {
    deleteChannelConfigStmt.run(channelId);
}

function getConfiguredTargets(guildId, sourceChannelId) {
    return getConfiguredTargetsStmt.all(sourceChannelId, guildId || '');
}

// ------------------------------------------------------------------
// Sender mode resolution: channel override -> group override -> guild default
// ------------------------------------------------------------------
function normalizeSendMode(value) {
    if (value === 'user' || value === 'bot') return value;
    return null;
}

function setChannelSendMode(channelId, mode) {
    setChannelSendModeStmt.run(normalizeSendMode(mode), channelId);
}

function setGroupChannelSendMode(groupName, guildId, channelId, mode) {
    setGroupChannelSendModeStmt.run(normalizeSendMode(mode), groupName, guildId || '', channelId);
}

function setGuildSendMode(guildId, mode) {
    // Guild-wide default lives in guild_settings; clear stale per-channel overrides
    // so the new default actually takes effect everywhere.
    setGuildSettingStmt.run(guildId, 'send_mode', normalizeSendMode(mode) || 'user');
    clearGuildChannelSendModeStmt.run(guildId || '');
}

function resolveSendMode(channelId, guildId, groupName) {
    const channelConfig = getChannelConfig(channelId);
    if (channelConfig && normalizeSendMode(channelConfig.send_mode)) {
        return channelConfig.send_mode;
    }
    if (groupName) {
        const groupChannel = getGroupChannelStmt.get(groupName, channelId);
        if (groupChannel && normalizeSendMode(groupChannel.send_mode)) {
            return groupChannel.send_mode;
        }
    }
    const guildDefault = getGuildSettingStmt.get(guildId || '', 'send_mode');
    return normalizeSendMode(guildDefault?.value) || 'user';
}

function shouldSendAsUser(channelId, guildId, groupName) {
    return resolveSendMode(channelId, guildId, groupName) === 'user';
}

// ------------------------------------------------------------------
// Translation groups
// ------------------------------------------------------------------
function getGroupTargets(groupName, guildId, sourceChannelId) {
    return getGroupTargetsStmt.all(groupName, guildId || '', sourceChannelId);
}

function getGroupsForSource(guildId, sourceChannelId) {
    return getGroupsForSourceStmt.all(guildId || '', sourceChannelId).map(row => row.group_name);
}

function getGroupChannels(groupName, guildId) {
    return getGroupChannelsStmt.all(groupName, guildId || '');
}

function getGuildGroupNames(guildId) {
    return getGuildGroupNamesStmt.all(guildId || '').map(row => row.group_name);
}

function getAllGroupNames() {
    return getAllGroupNamesStmt.all().map(row => row.group_name);
}

const replaceGroupChannels = db.transaction((groupName, guildId, channels) => {
    deleteGroupStmt.run(groupName, guildId || '');
    for (const entry of channels) {
        insertGroupChannelStmt.run(groupName, guildId || '', entry.channelId, entry.targetLanguage);
    }
});

function setGroupChannels(groupName, guildId, channels) {
    replaceGroupChannels(groupName, guildId, channels);
}

const addGroupChannelsTxn = db.transaction((groupName, guildId, channels) => {
    for (const entry of channels) {
        insertGroupChannelStmt.run(groupName, guildId || '', entry.channelId, entry.targetLanguage);
    }
});

function addGroupChannels(groupName, guildId, channels) {
    addGroupChannelsTxn(groupName, guildId, channels);
}

function removeGroupChannel(groupName, guildId, channelId) {
    return deleteGroupChannelStmt.run(groupName, guildId || '', channelId).changes > 0;
}

function deleteGroup(groupName, guildId) {
    return deleteGroupStmt.run(groupName, guildId || '').changes > 0;
}

// ------------------------------------------------------------------
// Message mappings (edit / delete sync)
// ------------------------------------------------------------------
function getMessageMapping(originalMessageId, targetChannelId) {
    return getMessageMappingStmt.get(originalMessageId, targetChannelId);
}

function getMessageMappings(originalMessageId) {
    return getMessageMappingsStmt.all(originalMessageId);
}

function saveMessageMapping(originalMessageId, targetChannelId, webhookMessageId, targetLanguage, threadId = null) {
    insertMessageMappingStmt.run(originalMessageId, targetChannelId, webhookMessageId, targetLanguage || '', threadId || null);
}

function deleteMessageMappings(originalMessageId) {
    deleteMessageMappingsStmt.run(originalMessageId);
}

// ------------------------------------------------------------------
// Per-guild settings (key/value)
// ------------------------------------------------------------------
function getGuildSetting(guildId, key) {
    const row = getGuildSettingStmt.get(guildId || '', key);
    return row ? row.value : null;
}

function getGuildSettings(guildId) {
    const out = {};
    for (const row of getGuildSettingsStmt.all(guildId || '')) {
        out[row.key] = row.value;
    }
    return out;
}

function setGuildSetting(guildId, key, value) {
    if (value == null) {
        deleteGuildSettingStmt.run(guildId || '', key);
        return;
    }
    setGuildSettingStmt.run(guildId || '', key, String(value));
}

function close() {
    if (db.open) {
        db.pragma('wal_checkpoint(TRUNCATE)');
        db.close();
    }
}

module.exports = {
    _db: db,
    getChannelConfig,
    getGuildChannelConfigs,
    getChannelTargetLanguage,
    setChannelTargetLanguage,
    setChannelWebhook,
    clearChannelWebhook,
    deleteChannelConfig,
    getConfiguredTargets,
    setChannelSendMode,
    setGroupChannelSendMode,
    setGuildSendMode,
    resolveSendMode,
    shouldSendAsUser,
    getGroupTargets,
    getGroupsForSource,
    getGroupChannels,
    getGuildGroupNames,
    getAllGroupNames,
    setGroupChannels,
    addGroupChannels,
    removeGroupChannel,
    deleteGroup,
    getMessageMapping,
    getMessageMappings,
    saveMessageMapping,
    deleteMessageMappings,
    getGuildSetting,
    getGuildSettings,
    setGuildSetting,
    close
};
