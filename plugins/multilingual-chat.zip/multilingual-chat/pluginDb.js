/**
 * Multilingual Chat Plugin Database
 *
 * Stores channel configuration and translated message mappings using SQLite.
 */

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, 'multilingual-chat.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS channel_config (
    channel_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL DEFAULT '',
    target_language TEXT NOT NULL DEFAULT '',
    webhook_id TEXT,
    webhook_token TEXT,
    send_as_user INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS group_channels (
    group_name TEXT NOT NULL,
    guild_id TEXT NOT NULL DEFAULT '',
    channel_id TEXT NOT NULL,
    target_language TEXT NOT NULL,
    PRIMARY KEY (group_name, channel_id)
);

CREATE TABLE IF NOT EXISTS message_map (
    original_message_id TEXT NOT NULL,
    target_channel_id TEXT NOT NULL,
    webhook_message_id TEXT NOT NULL,
    target_language TEXT NOT NULL,
    PRIMARY KEY (original_message_id, target_channel_id)
);
`);

const channelConfigColumns = db.prepare('PRAGMA table_info(channel_config)').all().map(row => row.name);
if (!channelConfigColumns.includes('guild_id')) {
    db.exec("ALTER TABLE channel_config ADD COLUMN guild_id TEXT NOT NULL DEFAULT ''");
}
if (!channelConfigColumns.includes('send_as_user')) {
    db.exec('ALTER TABLE channel_config ADD COLUMN send_as_user INTEGER NOT NULL DEFAULT 1');
}

const groupChannelColumns = db.prepare('PRAGMA table_info(group_channels)').all().map(row => row.name);
if (!groupChannelColumns.includes('guild_id')) {
    db.exec("ALTER TABLE group_channels ADD COLUMN guild_id TEXT NOT NULL DEFAULT ''");
}

const getChannelConfigStmt = db.prepare('SELECT guild_id, target_language, webhook_id, webhook_token, send_as_user FROM channel_config WHERE channel_id = ?');
const setChannelConfigStmt = db.prepare(`INSERT INTO channel_config (channel_id, guild_id, target_language, webhook_id, webhook_token, send_as_user)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(channel_id) DO UPDATE SET guild_id = excluded.guild_id, target_language = excluded.target_language
`);
const setChannelWebhookStmt = db.prepare(`INSERT INTO channel_config (channel_id, guild_id, target_language, webhook_id, webhook_token, send_as_user)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(channel_id) DO UPDATE SET webhook_id = excluded.webhook_id, webhook_token = excluded.webhook_token
`);
const setGuildSendAsUserStmt = db.prepare('UPDATE channel_config SET send_as_user = ? WHERE guild_id = ?');
const deleteChannelConfigStmt = db.prepare('DELETE FROM channel_config WHERE channel_id = ?');
const getConfiguredTargetsStmt = db.prepare(`
    SELECT target.channel_id AS target_channel_id, target.target_language
    FROM channel_config AS source
    JOIN channel_config AS target ON target.guild_id = source.guild_id
    WHERE source.channel_id = ?
      AND source.guild_id = ?
      AND source.target_language != ''
      AND target.target_language != ''
      AND target.channel_id != source.channel_id
`);

const getGroupTargetsStmt = db.prepare(`
    SELECT DISTINCT gc.channel_id AS target_channel_id, gc.target_language
    FROM group_channels AS gc
    JOIN group_channels AS src ON src.group_name = gc.group_name
        AND src.guild_id = gc.guild_id
    WHERE src.group_name = ?
      AND src.guild_id = ?
      AND src.channel_id = ?
      AND gc.channel_id != src.channel_id
`);
const getGroupsForSourceStmt = db.prepare('SELECT DISTINCT group_name FROM group_channels WHERE guild_id = ? AND channel_id = ?');
const getAllGroupNamesStmt = db.prepare('SELECT DISTINCT group_name FROM group_channels');
const deleteGroupStmt = db.prepare('DELETE FROM group_channels WHERE group_name = ? AND guild_id = ?');
const deleteGroupSourceStmt = db.prepare('DELETE FROM group_channels WHERE group_name = ? AND channel_id = ?');
const deleteGroupTargetStmt = db.prepare('DELETE FROM group_channels WHERE group_name = ? AND channel_id = ?');
const insertGroupTargetStmt = db.prepare(`INSERT INTO group_channels (group_name, guild_id, channel_id, target_language) VALUES (?, ?, ?, ?) ON CONFLICT(group_name, channel_id) DO UPDATE SET guild_id = excluded.guild_id, target_language = excluded.target_language`);

const getMessageMappingStmt = db.prepare('SELECT target_channel_id, webhook_message_id, target_language FROM message_map WHERE original_message_id = ? AND target_channel_id = ?');
const getMessageMappingsStmt = db.prepare('SELECT target_channel_id, webhook_message_id, target_language FROM message_map WHERE original_message_id = ?');
const insertMessageMappingStmt = db.prepare(`INSERT OR REPLACE INTO message_map (original_message_id, target_channel_id, webhook_message_id, target_language)
    VALUES (?, ?, ?, ?)
`);
const deleteMessageMappingsStmt = db.prepare('DELETE FROM message_map WHERE original_message_id = ?');

function getChannelConfig(channelId) {
    return getChannelConfigStmt.get(channelId);
}

function getChannelTargetLanguage(channelId) {
    const config = getChannelConfig(channelId);
    return config ? config.target_language : '';
}

function setChannelTargetLanguage(channelId, targetLanguage, guildId = '') {
    const stored = getChannelConfig(channelId);
    const webhookId = stored ? stored.webhook_id : null;
    const webhookToken = stored ? stored.webhook_token : null;
    const sendAsUser = stored ? stored.send_as_user : 1;
    setChannelConfigStmt.run(channelId, guildId || stored?.guild_id || '', targetLanguage || '', webhookId, webhookToken, sendAsUser);
}

function setChannelWebhook(channelId, webhookId, webhookToken) {
    const stored = getChannelConfig(channelId);
    const targetLanguage = stored ? stored.target_language : '';
    const sendAsUser = stored ? stored.send_as_user : 1;
    setChannelWebhookStmt.run(channelId, stored?.guild_id || '', targetLanguage, webhookId, webhookToken, sendAsUser);
}

function setGuildSendAsUser(guildId, enabled) {
    setGuildSendAsUserStmt.run(enabled ? 1 : 0, guildId);
}

function shouldSendAsUser(channelId) {
    const config = getChannelConfig(channelId);
    return config ? config.send_as_user !== 0 : true;
}

function deleteChannelConfig(channelId) {
    deleteChannelConfigStmt.run(channelId);
}

function getConfiguredTargets(guildId, sourceChannelId) {
    return getConfiguredTargetsStmt.all(sourceChannelId, guildId || '');
}

function getGroupTargets(groupName, guildId, sourceChannelId) {
    return getGroupTargetsStmt.all(groupName, guildId || '', sourceChannelId);
}

function getGroupsForSource(guildId, sourceChannelId) {
    return getGroupsForSourceStmt.all(guildId || '', sourceChannelId).map(row => row.group_name);
}

function getAllGroupNames() {
    return getAllGroupNamesStmt.all().map(row => row.group_name);
}

const replaceGroupChannels = db.transaction((groupName, guildId, channels) => {
    deleteGroupStmt.run(groupName, guildId || '');
    for (const entry of channels) {
        insertGroupTargetStmt.run(groupName, guildId || '', entry.channelId, entry.targetLanguage);
    }
});

function setGroupChannels(groupName, guildId, channels) {
    replaceGroupChannels(groupName, guildId, channels);
}

function setGroupTargets(groupName, guildId, sourceChannelId, targets) {
    const current = getGroupTargets(groupName, guildId, sourceChannelId).map(row => row.target_channel_id);
    const kept = new Set(targets.map(entry => entry.targetChannelId));

    for (const entry of targets) {
        insertGroupTargetStmt.run(groupName, guildId || '', entry.targetChannelId, entry.targetLanguage);
    }

    for (const existingChannelId of current) {
        if (!kept.has(existingChannelId)) {
            deleteGroupTargetStmt.run(groupName, existingChannelId);
        }
    }
}

function removeGroupTarget(groupName, sourceChannelId, targetChannelId) {
    const result = deleteGroupTargetStmt.run(groupName, sourceChannelId, targetChannelId);
    return result.changes > 0;
}

function deleteGroupForSource(groupName, sourceChannelId) {
    const result = deleteGroupSourceStmt.run(groupName, sourceChannelId);
    return result.changes > 0;
}

function getMessageMapping(originalMessageId, targetChannelId) {
    return getMessageMappingStmt.get(originalMessageId, targetChannelId);
}

function getMessageMappings(originalMessageId) {
    return getMessageMappingsStmt.all(originalMessageId);
}

function saveMessageMapping(originalMessageId, targetChannelId, webhookMessageId, targetLanguage) {
    insertMessageMappingStmt.run(originalMessageId, targetChannelId, webhookMessageId, targetLanguage || '');
}

function deleteMessageMappings(originalMessageId) {
    deleteMessageMappingsStmt.run(originalMessageId);
}

function close() {
    if (db.open) {
        db.pragma('wal_checkpoint(TRUNCATE)');
        db.close();
    }
}

module.exports = {
    getChannelConfig,
    getChannelTargetLanguage,
    setChannelTargetLanguage,
    setChannelWebhook,
    setGuildSendAsUser,
    shouldSendAsUser,
    deleteChannelConfig,
    getConfiguredTargets,
    getGroupTargets,
    getGroupsForSource,
    getAllGroupNames,
    setGroupChannels,
    setGroupTargets,
    removeGroupTarget,
    deleteGroupForSource,
    getMessageMapping,
    getMessageMappings,
    saveMessageMapping,
    deleteMessageMappings,
    close
};
