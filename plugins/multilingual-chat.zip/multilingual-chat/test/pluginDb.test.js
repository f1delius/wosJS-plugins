const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');

const dbFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'mlc-db-')), 'plugin.db');
process.env.MULTILINGUAL_CHAT_DB_PATH = dbFile;

const pluginDb = require('../pluginDb');

test.after(() => {
    pluginDb.close();
    fs.rmSync(path.dirname(dbFile), { recursive: true, force: true });
});

test('channel config round-trips with guild id', () => {
    pluginDb.setChannelTargetLanguage('chan-en', 'en', 'guild-1');
    pluginDb.setChannelTargetLanguage('chan-fr', 'fr', 'guild-1');

    assert.equal(pluginDb.getChannelTargetLanguage('chan-en'), 'en');
    const targets = pluginDb.getConfiguredTargets('guild-1', 'chan-en');
    assert.deepEqual(targets.map(t => t.target_channel_id).sort(), ['chan-fr']);
});

test('disabling a channel clears it from fan-out', () => {
    pluginDb.setChannelTargetLanguage('chan-fr', '', 'guild-1');
    assert.equal(pluginDb.getConfiguredTargets('guild-1', 'chan-en').length, 0);
    pluginDb.setChannelTargetLanguage('chan-fr', 'fr', 'guild-1');
});

test('sender mode resolves channel -> group -> guild default', () => {
    // default
    assert.equal(pluginDb.resolveSendMode('chan-en', 'guild-1'), 'user');

    pluginDb.setGuildSendMode('guild-1', 'bot');
    assert.equal(pluginDb.resolveSendMode('chan-en', 'guild-1'), 'bot');

    pluginDb.setChannelSendMode('chan-en', 'user');
    assert.equal(pluginDb.resolveSendMode('chan-en', 'guild-1'), 'user');
    assert.ok(pluginDb.shouldSendAsUser('chan-en', 'guild-1'));

    pluginDb.setChannelSendMode('chan-en', null);
    assert.equal(pluginDb.resolveSendMode('chan-en', 'guild-1'), 'bot');

    pluginDb.setGuildSendMode('guild-1', 'user');
});

test('groups: create, add, remove, delete', () => {
    pluginDb.setGroupChannels('team', 'guild-1', [
        { channelId: 'g-en', targetLanguage: 'en' },
        { channelId: 'g-fr', targetLanguage: 'fr' }
    ]);
    assert.deepEqual(pluginDb.getGuildGroupNames('guild-1'), ['team']);
    assert.equal(pluginDb.getGroupChannels('team', 'guild-1').length, 2);

    pluginDb.addGroupChannels('team', 'guild-1', [{ channelId: 'g-de', targetLanguage: 'de' }]);
    assert.equal(pluginDb.getGroupChannels('team', 'guild-1').length, 3);

    const fromEn = pluginDb.getGroupTargets('team', 'guild-1', 'g-en').map(r => r.target_channel_id).sort();
    assert.deepEqual(fromEn, ['g-de', 'g-fr']);

    assert.ok(pluginDb.removeGroupChannel('team', 'guild-1', 'g-de'));
    assert.equal(pluginDb.getGroupChannels('team', 'guild-1').length, 2);
    assert.ok(!pluginDb.removeGroupChannel('team', 'guild-1', 'nope'));

    assert.ok(pluginDb.deleteGroup('team', 'guild-1'));
    assert.equal(pluginDb.getGuildGroupNames('guild-1').length, 0);
});

test('message mappings store thread id and clear together', () => {
    pluginDb.saveMessageMapping('orig-1', 'chan-fr', 'wh-1', 'fr', 'thread-9');
    pluginDb.saveMessageMapping('orig-1', 'chan-de', 'wh-2', 'de', null);

    const all = pluginDb.getMessageMappings('orig-1');
    assert.equal(all.length, 2);
    assert.equal(pluginDb.getMessageMapping('orig-1', 'chan-fr').thread_id, 'thread-9');

    pluginDb.deleteMessageMappings('orig-1');
    assert.equal(pluginDb.getMessageMappings('orig-1').length, 0);
});

test('guild settings round-trip and delete on null', () => {
    pluginDb.setGuildSetting('guild-1', 'min_chars', '5');
    assert.equal(pluginDb.getGuildSetting('guild-1', 'min_chars'), '5');
    assert.equal(pluginDb.getGuildSettings('guild-1').min_chars, '5');

    pluginDb.setGuildSetting('guild-1', 'min_chars', null);
    assert.equal(pluginDb.getGuildSetting('guild-1', 'min_chars'), null);
});
