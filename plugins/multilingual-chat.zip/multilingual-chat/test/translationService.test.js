const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mlc-svc-'));
process.env.MULTILINGUAL_CHAT_DB_PATH = path.join(dir, 'plugin.db');

const pluginDb = require('../pluginDb');
const settings = require('../lib/settings');
const {
    resolveSourceParts,
    collectAttachments,
    shouldIgnore,
    isCommandLike,
    buildBody,
    translateText
} = require('../lib/translationService');

test.after(() => {
    pluginDb.close();
    fs.rmSync(dir, { recursive: true, force: true });
});

function collection(items) {
    return new Map(items.map((item, i) => [String(i), item]));
}

test('resolveSourceParts reads a normal message', () => {
    const parts = resolveSourceParts({
        content: '  hello  ',
        attachments: collection([{ url: 'https://x/a.png', name: 'a.png' }])
    });
    assert.equal(parts.isForward, false);
    assert.equal(parts.content, 'hello');
    assert.equal([...parts.attachments.values()].length, 1);
});

test('resolveSourceParts unwraps a forwarded message snapshot', () => {
    const message = {
        content: '',
        attachments: collection([]),
        reference: { type: 1 }, // MessageReferenceType.Forward
        messageSnapshots: {
            first: () => ({
                content: 'forwarded text',
                attachments: collection([{ url: 'https://x/f.jpg', name: 'f.jpg' }]),
                embeds: []
            })
        }
    };
    const parts = resolveSourceParts(message);
    assert.equal(parts.isForward, true);
    assert.equal(parts.content, 'forwarded text');
    assert.equal([...parts.attachments.values()][0].name, 'f.jpg');
});

test('collectAttachments enforces count and size caps', () => {
    settings.set('g', 'max_attachments', 2);
    settings.set('g', 'max_attachment_mb', 1);

    const atts = collection([
        { url: 'u1', name: '1', size: 500 },
        { url: 'u2', name: '2', size: 500 },
        { url: 'u3', name: '3', size: 500 },              // over count cap
        { url: 'u4', name: '4', size: 5 * 1024 * 1024 }   // over size cap
    ]);
    const { files, overflowUrls } = collectAttachments(atts, 'g');
    assert.equal(files.length, 2);
    assert.deepEqual(overflowUrls.sort(), ['u3', 'u4']);
});

test('shouldIgnore skips bots, webhooks, system and ignored channels', () => {
    const base = { guild: { id: 'g' }, channel: { id: 'c', parentId: null } };
    assert.ok(shouldIgnore({ ...base, author: { bot: true } }, 'g', 'c'));
    assert.ok(shouldIgnore({ ...base, webhookId: '123', author: {} }, 'g', 'c'));
    assert.ok(shouldIgnore({ ...base, system: true, author: {} }, 'g', 'c'));
    assert.ok(!shouldIgnore({ ...base, author: { bot: false } }, 'g', 'c'));

    settings.addToList('g', 'ignore_channels', 'c');
    assert.ok(shouldIgnore({ ...base, author: {} }, 'g', 'c'));
    settings.removeFromList('g', 'ignore_channels', 'c');
});

test('isCommandLike matches configured prefixes', () => {
    assert.ok(isCommandLike('!ping', 'g'));
    assert.ok(isCommandLike('/help', 'g'));
    assert.ok(!isCommandLike('hello world', 'g'));
    assert.ok(!isCommandLike('', 'g'));
});

test('buildBody adds forward marker and bot-mode header', () => {
    pluginDb.setChannelTargetLanguage('target', 'fr', 'g');
    pluginDb.setChannelSendMode('target', 'bot');

    const body = buildBody({
        message: { author: { tag: 'alice#1' } },
        sourceParts: { isForward: true, replyContext: 'reply to bob: hi' },
        targetChannelId: 'target',
        guildId: 'g',
        targetLanguage: 'fr',
        bodyText: 'bonjour',
        translationFailed: false,
        overflowUrls: ['https://x/big.zip']
    });

    assert.match(body, /forwarded message/);
    assert.match(body, /reply to bob/);
    assert.match(body, /Translation \(fr\).*alice#1/);
    assert.match(body, /bonjour/);
    assert.match(body, /big\.zip/);

    pluginDb.setChannelSendMode('target', null);
});

test('buildBody in user mode is just the text', () => {
    pluginDb.setChannelSendMode('target', null);
    const body = buildBody({
        message: { author: { tag: 'alice#1' } },
        sourceParts: { isForward: false, replyContext: null },
        targetChannelId: 'target',
        guildId: 'g',
        targetLanguage: 'fr',
        bodyText: 'bonjour',
        translationFailed: false,
        overflowUrls: []
    });
    assert.equal(body, 'bonjour');
});

test('translateText returns null for empty input without network', async () => {
    assert.equal(await translateText('', 'fr'), null);
    assert.equal(await translateText('hi', ''), null);
});
