const test = require('node:test');
const assert = require('node:assert/strict');

const {
    resolveLanguage,
    isSupportedLanguage,
    sameLanguage,
    normalizeLanguage
} = require('../lib/languages');

test('resolves plain codes', () => {
    assert.equal(resolveLanguage('EN'), 'en');
    assert.equal(resolveLanguage(' fr '), 'fr');
    assert.equal(resolveLanguage('zh-cn'), 'zh-cn');
});

test('resolves friendly names and aliases', () => {
    assert.equal(resolveLanguage('english'), 'en');
    assert.equal(resolveLanguage('French'), 'fr');
    assert.equal(resolveLanguage('German'), 'de');
    assert.equal(resolveLanguage('simplified chinese'), 'zh-cn');
    assert.equal(resolveLanguage('Chinese (Traditional)'), 'zh-tw');
    assert.equal(resolveLanguage('brazilian portuguese'), 'pt');
});

test('resolves regional variants to a supported base', () => {
    assert.equal(resolveLanguage('en-US'), 'en');
    assert.equal(resolveLanguage('pt_BR'), 'pt');
});

test('isSupportedLanguage accepts codes and aliases, rejects junk', () => {
    assert.ok(isSupportedLanguage('english'));
    assert.ok(isSupportedLanguage('zh-tw'));
    assert.ok(!isSupportedLanguage('klingon'));
    assert.ok(!isSupportedLanguage(''));
});

test('sameLanguage compares on base subtag but keeps zh variants distinct', () => {
    assert.ok(sameLanguage('en', 'en-GB'));
    assert.ok(sameLanguage('english', 'en'));
    assert.ok(!sameLanguage('zh-cn', 'zh-tw'));
    assert.ok(sameLanguage('zh-cn', 'chinese'));
    assert.ok(!sameLanguage('en', 'fr'));
    assert.ok(!sameLanguage('', 'en'));
});

test('normalizeLanguage is null-safe', () => {
    assert.equal(normalizeLanguage(null), '');
    assert.equal(normalizeLanguage(undefined), '');
});
