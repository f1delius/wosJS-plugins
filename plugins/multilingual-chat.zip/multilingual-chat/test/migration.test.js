const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const Database = require('better-sqlite3');

// Build a database that looks like the ORIGINAL plugin schema (v1.0.0):
// no guild_id, no send_mode, no thread_id, no guild_settings table.
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mlc-mig-'));
const dbFile = path.join(dir, 'legacy.db');

{
    const legacy = new Database(dbFile);
    legacy.exec(`
        CREATE TABLE channel_config (
            channel_id TEXT PRIMARY KEY,
            target_language TEXT NOT NULL DEFAULT '',
            webhook_id TEXT,
            webhook_token TEXT,
            send_as_user INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE group_channels (
            group_name TEXT NOT NULL,
            channel_id TEXT NOT NULL,
            target_language TEXT NOT NULL,
            PRIMARY KEY (group_name, channel_id)
        );
        CREATE TABLE message_map (
            original_message_id TEXT NOT NULL,
            target_channel_id TEXT NOT NULL,
            webhook_message_id TEXT NOT NULL,
            target_language TEXT NOT NULL,
            PRIMARY KEY (original_message_id, target_channel_id)
        );
    `);
    legacy.prepare('INSERT INTO channel_config (channel_id, target_language, send_as_user) VALUES (?, ?, ?)').run('old-bot', 'en', 0);
    legacy.prepare('INSERT INTO channel_config (channel_id, target_language, send_as_user) VALUES (?, ?, ?)').run('old-user', 'fr', 1);
    legacy.prepare('INSERT INTO message_map VALUES (?, ?, ?, ?)').run('m1', 'old-user', 'wh1', 'fr');
    legacy.close();
}

process.env.MULTILINGUAL_CHAT_DB_PATH = dbFile;
const pluginDb = require('../pluginDb');

test.after(() => {
    pluginDb.close();
    fs.rmSync(dir, { recursive: true, force: true });
});

test('adds new columns without losing rows', () => {
    const cols = pluginDb._db.prepare('PRAGMA table_info(channel_config)').all().map(c => c.name);
    assert.ok(cols.includes('guild_id'));
    assert.ok(cols.includes('send_mode'));

    const mapCols = pluginDb._db.prepare('PRAGMA table_info(message_map)').all().map(c => c.name);
    assert.ok(mapCols.includes('thread_id'));

    assert.equal(pluginDb.getChannelTargetLanguage('old-bot'), 'en');
    assert.equal(pluginDb.getMessageMappings('m1').length, 1);
});

test('legacy send_as_user=0 becomes send_mode=bot', () => {
    assert.equal(pluginDb.resolveSendMode('old-bot', ''), 'bot');
    assert.equal(pluginDb.resolveSendMode('old-user', ''), 'user');
});

test('guild_settings table is created', () => {
    pluginDb.setGuildSetting('', 'min_chars', '3');
    assert.equal(pluginDb.getGuildSetting('', 'min_chars'), '3');
});
