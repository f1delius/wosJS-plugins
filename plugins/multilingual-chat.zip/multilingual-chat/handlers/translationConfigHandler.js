const { MessageFlags } = require('discord.js');

/**
 * The plugin is configured entirely through slash commands. This handler just
 * catches any stray component interactions using the plugin's prefix and points
 * users at the right command.
 */
module.exports = function (client) {
    async function listener(interaction) {
        if (!interaction.isButton() && !interaction.isStringSelectMenu()) return;
        if (!interaction.customId.startsWith('multilingual-chat_')) return;

        await interaction.reply({
            content: 'Translation settings are managed via slash commands: `/translate set`, `/translate options`, `/translate list`, `/link create`, `/link add`, `/link list`.',
            flags: MessageFlags.Ephemeral
        }).catch(() => {});
    }

    client.on('interactionCreate', listener);
    return () => client.off('interactionCreate', listener);
};
