const { MessageFlags } = require('discord.js');

module.exports = function (client) {
    async function listener(interaction) {
        if (!interaction.isButton() && !interaction.isStringSelectMenu()) return;
        if (!interaction.customId.startsWith('multilingual-chat_')) return;

        await interaction.reply({
            content: 'Translation configuration is managed via slash commands. Use /translate set, /translate disable, or /translate status.',
            flags: MessageFlags.Ephemeral
        });
    }

    client.on('interactionCreate', listener);
    return () => client.off('interactionCreate', listener);
};
