const { Events } = require('discord.js');
const { deleteTranslationForMessage } = require('../lib/translationService');

module.exports = {
    name: Events.MessageDelete,
    once: false,
    async execute(message) {
        try {
            if (!message?.id) return;
            // Ignore deletions of our own webhook posts (avoids feedback loops).
            if (message.webhookId) return;
            await deleteTranslationForMessage(message.id);
        } catch (error) {
            console.error('[multilingual-chat] messageDelete error:', error.message || error);
        }
    }
};
