const { Events } = require('discord.js');
const { deleteTranslationForMessage } = require('../lib/translationService');

module.exports = {
    name: Events.MessageDelete,
    once: false,
    async execute(message) {
        if (message.author?.bot) return;
        await deleteTranslationForMessage(message.id);
    }
};
