const { Events } = require('discord.js');
const { updateTranslationForMessage } = require('../lib/translationService');

module.exports = {
    name: Events.MessageUpdate,
    once: false,
    async execute(oldMessage, newMessage) {
        if (newMessage.author?.bot) return;
        if (!newMessage.guild || !newMessage.channel) return;
        if (newMessage.content === oldMessage.content) return;

        await updateTranslationForMessage(newMessage);
    }
};
