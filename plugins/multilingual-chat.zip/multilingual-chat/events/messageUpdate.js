const { Events } = require('discord.js');
const { updateTranslationForMessage } = require('../lib/translationService');

module.exports = {
    name: Events.MessageUpdate,
    once: false,
    async execute(oldMessage, newMessage) {
        try {
            if (!newMessage || newMessage.author?.bot || newMessage.webhookId) return;
            if (!newMessage.guild || !newMessage.channel) return;
            if (oldMessage && newMessage.content === oldMessage.content) return;

            await updateTranslationForMessage(newMessage);
        } catch (error) {
            console.error('[multilingual-chat] messageUpdate error:', error.message || error);
        }
    }
};
