const { Events } = require('discord.js');
const { deleteTranslationForMessage } = require('../lib/translationService');

module.exports = {
    name: Events.MessageBulkDelete,
    once: false,
    async execute(messages) {
        try {
            const ids = messages?.keys ? [...messages.keys()] : [];
            for (const id of ids) {
                await deleteTranslationForMessage(id);
            }
        } catch (error) {
            console.error('[multilingual-chat] messageDeleteBulk error:', error.message || error);
        }
    }
};
