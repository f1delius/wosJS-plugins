const { Events } = require('discord.js');
const { handleIncomingMessage } = require('../lib/translationService');

module.exports = {
    name: Events.MessageCreate,
    once: false,
    async execute(message) {
        try {
            await handleIncomingMessage(message);
        } catch (error) {
            console.error('[multilingual-chat] messageCreate error:', error.message || error);
        }
    }
};
