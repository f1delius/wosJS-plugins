const { Events } = require('discord.js');
const pluginDb = require('../pluginDb');
const { sendConfiguredTranslations } = require('../lib/translationService');
const { sendGroupTranslations } = require('../lib/groupTranslationService');

module.exports = {
    name: Events.MessageCreate,
    once: false,
    async execute(message) {
        if (message.author?.bot) return;
        if (!message.guild || !message.channel) return;

        const groupTargets = pluginDb.getGroupsForSource(message.guild.id, message.channel.id);
        if (groupTargets.length) {
            return await sendGroupTranslations(message);
        }

        await sendConfiguredTranslations(message);
    }
};
